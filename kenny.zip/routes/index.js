var express = require('express');
var router = express.Router();
const qr = require("qrcode");

/* GET home page. */
let e = ''; 
router.post('/data', function(req, res, next) {

  res.redirect('/')
  e = req.body.email
    // console.log(req.body);
})

router.get('/', function(req, res, next) {

    const url = "mayor is a fool";
    
    qr.toDataURL(e, (err, src) => {
        if (err) res.send("Error occured");
        res.render("index", { data: src });
    });
});

module.exports = router;